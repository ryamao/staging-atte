<tr>
    <td>{{ $date }}</td>
    <td>{{ $shiftBegunAt }}</td>
    <td>{{ $shiftEndedAt }}</td>
    <td>{{ $breakSeconds }}</td>
    <td>{{ $workSeconds }}</td>
</tr>