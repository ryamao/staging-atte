<tr>
    <td>{{ $userName }}</td>
    <td>{{ $shiftBegunAt }}</td>
    <td>{{ $shiftEndedAt }}</td>
    <td>{{ $breakSeconds }}</td>
    <td>{{ $workSeconds }}</td>
</tr>